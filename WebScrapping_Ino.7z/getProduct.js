var Nightmare = require('nightmare');
var fs = require('fs');
var http = require('http');
require('nightmare-upload')(Nightmare);
var tempArr='';
new Nightmare()
.viewport(1356,3000)
  .goto('https://www.alibaba.com/product-detail/12-18mesh-10-16mesh-Natural-Raw_60470177741.html?spm=a2700.7724856.0.0.KorXOH&s=p')
.wait()
    /*.evaluate(function(){
        for(i=0;i<10;i++)
            {
                setTimeout(function(){
                    window.scrollTo(0,i*300);
                },100)
            }
    })*/
    .wait(1000)
.evaluate(function(){
      /*var categoryFolder = 'Agriculture';
        var subCategoryFolder = 'Agricultural Growing Media';
        var tempArr ='';
        var temp = document.querySelectorAll('body > div.l-page > div.l-page-main > div.l-main-content > div.l-grid.l-grid-sub.l-grid-extra > div.l-col-main > div > div:nth-child(4) img');
        for (var iterate = 0; iterate < temp.length; iterate++) {
            tempArr += '{"folder":"'+categoryFolder+'","subfolder":"'+subCategoryFolder+'","url":"'+temp[iterate].getAttribute('src') +'"}';
             if(iterate != temp.length-1)
                tempArr += ',';
        }*/
    return 'asdfa';
},function(i){
    console.log('afaf');
})
    .screenshot('sss.png')
.run(function(err, nightmare) {
    if (err) {
      console.log(err);
    }
    //console.log(tempArr);
    console.log('Done.');
  });