var Nightmare = require('nightmare');
var request = require('request');
require('nightmare-upload')(Nightmare);
new Nightmare()
    .viewport(1356, 786)
    .goto('https://www.alibaba.com/product-detail/12-18mesh-10-16mesh-Natural-Raw_60470177741.html?spm=a2700.7724856.0.0.KorXOH&s=p')
    .wait()
/*
    .evaluate(function () {
    var breadCrumb = document.querySelector('#J-ls-content > div.grid.grid-c2-e5.ls-grid-bcl > div.col-main > div > div > div.ui-breadcrumb').textContent;
    var details = document.querySelector('#J-ls-content > div.grid.grid-c2-e6.ls-grid-main > div.col-main');
    var result = '{"breadcrumb":"'+breadCrumb+'"}';
    
    },function(result){
        console.log(result);
    })*/
    .screenshot('product.png')
    .run()
    .then(function(){
    console.log('RUNNING');
    download('http://digitaleeditie.nrc.nl/digitaleeditie/helekrant/epub/nrc_20141124.epub', 'myBook.epub',function () {
      console.log('done');
    });
});

function download(uri, filename, callback) {
  request.head(uri, function () {
    request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
  });
}