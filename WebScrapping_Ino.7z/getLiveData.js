var casper = require('casper').create();
var selecpath = require('casper').selectXPath;
//casper.userAgent('Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)');
phantom.casperTest = true;
// Opens casperjs homepage
casper.start('https://swishanalytics.com/optimus/mlb/fanduel-draftkings-live-scoring');
var linksPitchers = '';
casper.then(function () {
  console.log('working');  

});
//Click on the menu button as it is opening mobile site
casper.thenClick(selecpath('//*[@id="menu1"]/label'),function(){
    console.log('clickon login');
	casper.capture('web.png');
});

//wait for 100ms 
casper.wait(100,function(){
});

//click on the login button from the menu
casper.thenClick(selecpath('//*[@id="menu1"]/ul/li[6]/a'),function(){
});

//wait for 200ms 
casper.wait(200,function(){
});

//Click on the login tab from the popup
casper.thenClick(selecpath('//*[@id="innerLoginTab"]'),function(){	
});

////wait for 100ms 
casper.wait(200,function(){
    
    //Set login id and password
	this.sendKeys('#login_email','dke5@georgetown.edu');
	this.sendKeys('#login_password','And1Analytics12');
 
    //Click on the login button
	casper.thenClick(selecpath('//*[@id="login-button"]'),function(){
		console.log('Clicked Button');
	});
	
});

//Function to Get the data from the fanDuel table
function getTableData() {
    var playerPos = document.querySelector("table > tbody.helvetica.stat-table.batters-table.batters-body").childNodes;

    //table 
    xmlNodes = '<?xml version="1.0" encoding="UTF-8"?><players>';
    for(i=0;i<playerPos.length;i++)
        {
			var itemChild = playerPos[i].childNodes;
        var nameTruncate = itemChild[0].textContent.substr(0,itemChild[0].textContent.indexOf('(')).trim();
            
        xmlNodes += '<player><pos>' + itemChild[17].textContent + '</pos><playerName>'+nameTruncate+'</playerName></player>';
        }
    xmlNodes+='</players>';
    return xmlNodes;
}

//Function to Get the data from the fanDuel table
function getTableDataPitchers() {
    var playerPos = document.querySelector("table > tbody.helvetica.stat-table.pitchers-table.pitchers-body").childNodes;

    //table 
    xmlNodes = '<?xml version="1.0" encoding="UTF-8"?><players>';
    for(i=0;i<playerPos.length;i++)
        {
			var itemChild = playerPos[i].childNodes;
        var nameTruncate = itemChild[0].textContent.substr(0,itemChild[0].textContent.indexOf('(')).trim();
        xmlNodes += 
            '<player><pos>' + itemChild[15].textContent + '</pos><playerName>'+nameTruncate+'</playerName></player>';
        }
    xmlNodes+='</players>';
    return xmlNodes;
}
function clickMain(){
    var itt='';
    var btns = document.querySelectorAll('.console-toggle-1');
    for(var i =0;i<btns.length;i++)
        {
          //  btns[3].click();
            if(btns[i].textContent.indexOf('Main') >= 0)
            {
                //     btns[i].click();
                return i;
            }
            itt += ' '+btns[i].textContent.indexOf('Main');
        }
    return itt;
}
///html/body/div[3]/div[2]/div/div[3]/div/div/div[1]/button[3]
casper.back();
//Click on the menu button as it is opening mobile site
casper.thenClick(selecpath('//*[@id="menu1"]/label'),function(){
    console.log('clickon login');	
});

//Click on fanduel button and wait for the screen to load and capture screenshot
casper.wait(2000,function(){
	casper.thenClick(selecpath('/html/body/div[3]/div[2]/div/div[2]/div[2]/div'),function(){
		
        });
       casper.wait(6000,function(){
            var it =this.evaluate(clickMain);        
            ///html/body/div[3]/div[2]/div/div[3]/div/div/div[1]/button[3]
            var st = '/html/body/div[3]/div[2]/div/div[3]/div/div/div[1]/button['+(it+1)+']';
                console.log(st);
                casper.thenClick(selecpath('html/body/div[3]/div[2]/div/div[3]/div/div/div[1]/button[3]'),function(){
                    console.log('Click using selecPath');
                });
        casper.wait(6000,function(){
            casper.capture('web.png');
			//casper.capture('login.png'); //Capture the screenshot
		    links = this.evaluate(getTableData);
		});
	});
	 
	// casper.wait(6000,function(){casper.capture('right.png');});
});

//Click on PITCHERS button and wait for the screen to load and capture screenshot
casper.wait(6000,function(){
	casper.thenClick(selecpath('/html/body/div[3]/div[2]/div/div[5]/ul/li[2]/a'),function(){
		casper.wait(6000,function(){
			casper.capture('login11.png'); //Capture the screenshot
		    linksPitchers = this.evaluate(getTableDataPitchers);
		});
	});
	 
	// casper.wait(6000,function(){casper.capture('right.png');});
});

casper.run(function() {
    // Write the data to the file
    var fs = require('fs');
    var myfile = 'xml/batters.xml';
    fs.write(myfile, links, 'w');
	
   
	
	var fs = require('fs');
    var myfile = 'xml/pitchers.xml';
    fs.write(myfile, linksPitchers, 'w');
	 this.echo(linksPitchers);
    //this.echo(' - ' + links.join('\n - ')).exit();
    casper.exit();
});
