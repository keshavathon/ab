var MongoClient = require('mongodb').MongoClient;
var url = 'mongodb://127.0.0.1:27017/Ino';
var item = 'jhg';
MongoClient.connect(url, function (err, db) {
    var request = require("request")
        , cheerio = require("cheerio")
        , url = "https://www.alibaba.com/product-detail/12-18mesh-10-16mesh-Natural-Raw_60470177741.html?spm=a2700.7724856.0.0.KorXOH&s=p";
    var fs = require('fs');
    var myfile = 'dataFiles/Agriculture/productImageSrc_1.json';
    var fileData =fs.readFile(myfile, function (err, data) {
        //console.log(data);
        console.log('working');
        var json = JSON.parse(data);
        console.log("Connected correctly to server.");
        for (indexJson = 0; indexJson < 1; indexJson++) {
            url = json[indexJson].url;
            console.log(url + 'adfasdf');
            request(url, function (error, response, body) {
                if (!error) {
                    var $ = cheerio.load(body)
                        , breadCrumb = $("#J-ls-content > div.grid.grid-c2-e5.ls-grid-bcl > div.col-main > div > div > div.ui-breadcrumb").text();
                    var temp = $('body > div.l-page > div.l-page-main > div.l-main-content > div.l-grid.l-grid-sub.l-grid-extra > div.l-col-main > div > div:nth-child(4) img');
                    var categoryFolder = 'Agriculture';
                    var subCategoryFolder = 'Agricultural Growing Media';
                    var tempArr = '';
                    breadCrumb = breadCrumb.replace(/\s/g, "");
                    for (var iterate = 0; iterate < temp.length; iterate++) {
                        tempArr += '{"folder":"' + categoryFolder + '","subfolder":"' + subCategoryFolder + '","url":"' + temp[iterate].getAttribute('src') + '"}';
                        if (iterate != temp.length - 1) tempArr += ',';
                    }
                    var html = body.replace(/\s/g, "");
                    //console.log(html);
                    html = html.replace(/"/g, "@");
                    //GET SELLER INFORMATION
                    var seller = $('#J-ls-content > div.grid.grid-c2-e6.ls-grid-main > div.col-extra > div > div.extra-card > div > div.card-supplier > a.company-name.link-default'); // + 'contactinfo.html';
                    //  var data = '{"category":"","subcategory":"","pageURL":"' + url + '","pageHtml":"' + html + '","sellerName":"' + seller.text() + '","sellerWebsite":"' + seller.attr('href') + '","breadCrumb":"' + breadCrumb + '"}';
                    var data = '{"category":"","subcategory":"","pageURL":"' + url + '","sellerName":"' + seller.text() + '","sellerWebsite":"' + seller.attr('href') + '","breadCrumb":"' + breadCrumb;
                    //  data = JSON.parse(data);
                    //PUT DATA IN MONGODB
                    /*db.collection('ad').insert(data, function (err, records) {
                        console.log('Data is inserted correctly Into MongoDB');
                        db.close();
                    });*/
                    var item = '';
                    var sellerO = seller;
                    seller = seller.attr('href') + 'contactinfo.html';
                    //OPEN SELLER CONTACT PAGE
                    request(seller, function (error, response, body) {
                        var $j = cheerio.load(body);
                        item = $j('.company-info-data tr:nth-child(3) > td:nth-child(3) > a');
                        var sellerBody = '';
                        //OPEN SELLER WEBSITE
                        request($j(item[0]).attr('href'), function (error, response, body) {
                            //var data = '';
                            sellerBody = body;
                            console.log(item.length);
                            dataSeller = '{"sellerName":"' + sellerO.text() + '","sellerWebsite":"' + sellerO.attr('href') + '"}';
                            dataSeller = JSON.parse(dataSeller);
                            db.collection('sellerData').insert(dataSeller, function (err, records) {
                                console.log('Seller Data is inserted correctly Into MongoDB');
                                dataSeller = (records.ops[0]._id);
                                db.close();
                            });
                            data += '","sellerID":"' + dataSeller + '"}';
                            data = JSON.parse(data);
                            console.log(data);
                            db.collection('scrapPage').insert(data, function (err, records) {
                                console.log('Page Data is inserted correctly Into MongoDB');
                                console.log(records.ops[0]._id);
                                db.close();
                            });
                            json[indexJson].done = true;
                            console.log(json);
                            fs.writeFile(myfile, JSON.stringify(json));
                            //console.log(body);
                        });
                        //item = item.replace(/\s/g, '');
                        console.log(item.length);
                    });
                    console.log(seller);
                }
                else {
                    console.log("We’ve encountered an error: " + error);
                }
            });
        }
    });
});