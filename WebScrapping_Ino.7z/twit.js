
var Twit = require('twit')
var config = {
  consumer_key:         'TxPYSE5qbhjFFryVjvRyhONFU',
  consumer_secret:      'qyVsD6lZF3R1W4q6dntOMa3W4m0BcIqwoQRBoUX4mjLsgMaYri',
  access_token:         '4369830973-tFHHSQZ1pLl5RfQoEIZFwSnUOxxsKx64MWvPLzs',
  access_token_secret:  'DQaErvhyD3v53GZTgl21Gn86NMimqwJ79sgl0kEyGqoBg'
}
var fs = require('fs'),
    path = require('path'),
    Twit = require('twit');
    //config = require(path.join(__dirname, 'config.js'));
    
var T = new Twit(config);


function upload_random_image(){
  console.log('Opening an image...');
  var image_path = 'twitter.png',
      b64content = fs.readFileSync(image_path, { encoding: 'base64' });

  console.log('Uploading an image...');

  T.post('media/upload', { media_data: b64content }, function (err, data, response) {
    if (err){
      console.log('ERROR');
      console.log(err);
    }
    else{
      console.log('Uploaded an image!');

      T.post('statuses/update', {
        media_ids: new Array(data.media_id_string)
      },
        function(err, data, response) {
          if (err){
            console.log('Error!');
            console.log(err);
          }
          else{
            console.log('Posted an image!');
          }
        }
      );
    }
  });
};
upload_random_image();
/*
var Nightmare = require('nightmare');
require('nightmare-upload')(Nightmare)
new Nightmare()
.viewport(1356,786)
  .goto('https://twitter.com/login')
  /*.type('#page-container > div > div.signin-wrapper > form > fieldset > div:nth-child(2) > input', 'engg.keshav@gmail.com') // Substitute with your username
  .type('#page-container > div > div.signin-wrapper > form > fieldset > div:nth-child(3) > input', 'twitter@123') // Substitute with your password
  .click('button[type=submit]')*/
  /*.wait()
    .click('#global-new-tweet-button')
 /* .evaluate(function () {
    document.querySelector('#tweet-box-home-timeline').click();
})*/
  /*.evaluate(function () {
    document.querySelector('#tweet-box-global > div').textContent = '';
  })
  .type('#tweet-box-home-timeline  div','tweet text')
  .upload('input[type=file]','twitter.png')
.wait()
  //.evaluate(function(){document.querySelector('input[type=file]').click()})
    .screenshot('screen.png')
.click('#global-tweet-dialog-dialog > div.modal-content > div.modal-tweet-form-container > form > div.TweetBoxToolbar > div.TweetBoxToolbar-tweetButton.tweet-button > button')
.wait()
  .run(function(err, nightmare) {
    if (err) {
      console.log(err);
    }
    console.log('Done.');
  });*/


/*//FETCH HTML, LINKS, IMAGES OF PRODUCT PAGES
var casper = require('casper').create();

var selecpath = require('casper').selectXPath;
var links = '';
casper.viewport
casper.start('https://twitter.com');
casper.then(function () {
	console.log('run');
});
casper.thenClick(selecpath('//*[@id="doc"]/div[1]/div/div[1]/div[2]/a[3]'),function(){
	this.sendKeys(selecpath('//*[@id="login-dialog-dialog"]/div[2]/div[2]/div[2]/form/div[1]/input'),'engg.keshav@gmail.com');
	this.sendKeys(selecpath('//*[@id="login-dialog-dialog"]/div[2]/div[2]/div[2]/form/div[2]/input'),'twitter@123');
	console.log('running');
	casper.thenClick(selecpath('//*[@id="login-dialog-dialog"]/div[2]/div[2]/div[2]/form/input[1]'),function(){
		
	});
});
casper.wait(600,function(){
	//casper.thenClick(selecpath('//*[@id="global_nav"]/tbody/tr/td[5]/a'),function(){
	console.log('clicked');
	casper.scrollTo(10,900);
	//	});
	var item = this.evaluate(function(){
		//document.querySelector('li.topbar-tweet-btn button').click();
		return document.querySelector('#timeline > div.timeline-tweet-box > div > form > div:nth-child(3) > div').textContent;
	});
	console.log(item);
});

casper.wait(5000,function(){
	casper.capture('twitter0.png');
});
/*casper.wait(1,function(){
	var item = this.evaluate(function(){
		document.querySelector('#timeline > div.timeline-tweet-box > div > form > div:nth-child(3) > div').textContent = 'asdfasd';
		return document.querySelector('#timeline > div.timeline-tweet-box > div > form > div:nth-child(3) > div').textContent;
	});
	console.log(item);
});
*/
//PLAIN TWEETS
/*
casper.thenOpen('https://twitter.com/intent/tweet',function(){
	this.sendKeys(selecpath('//*[@id="status"]'),'asdfasdf');
	casper.thenClick(selecpath('//*[@id="update-form"]/div[3]/fieldset/input[2]'));
});*/


/*
casper.wait(10,function(){
	var item = this.evaluate(function(){
		document.querySelector('#tweet-box-home-timeline > div').textContent = 'asdfasdf';
		return document.querySelector('#tweet-box-home-timeline > div').textContent;
	});
	console.log(item);
})*/
//casper.wait(500,function(){
	//this.sendKeys(seleccpath('#tweet-box-global > div'),'Tweet text');
//});

/*casper.waitForSelector(selecpath('#global-new-tweet-button'),function(){
	casper.thenClick(selecpath('#global-new-tweet-button'),function(){});
},15000);


*/
/*
casper.run(function(){
	casper.capture('twitter.png');
casper.exit();
});
	*/